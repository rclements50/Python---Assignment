//On load the website hides the list items (after the first) and form and uses animation to reposition them off screen
$(document).ready(function(){
    $("#two, #three, #four, #five").animate({
        right: "2000px",
    });
});
//On click the list is set to show and then animates by sliding in from the left side of the screen in original position
$("#container").click(function(){
    $("#two").css({"visibility": "visible"});
    $("#two").animate({
        right: "0px",
    });
    $("#container").click(function(){
        $("#three").css({"visibility": "visible"});
        $("#three").animate({
            right: "-20px",
        });
        $("#container").click(function(){
            $("#four").css({"visibility": "visible"});
            $("#four").animate({
                right: "-40px",
            });
            $("#container").click(function(){
                $("#five").css({"visibility": "visible"});
                $("#five").animate({
                    right: "-60px",
                });
            });
        });
    });
});
//Add driver button reveals data form through a toggle reveal
$(".adddriver").click(function(){
    $("#dataform").toggle(1000)
    //Sets the focus into the driver name text box when the add driver form appears
    $("#dname").focus();
});


//SUBMIT
//Submit button adds form details to list
$('#dataform').submit(function(evt) {
//Picks up on blank fields and returns them as an error
    evt.preventDefault();
    error = false;
    var name = $("#dname").val();
    var country = $("#country").val();
    var team = $("#team").val();
    var score = $("#score").val();


//VALIDATION
//Checks the name to see if it is less than two letters. Allows anything over two letters to allow for names such as "Al" or "Ed".
//Outputs an error message if less than two.
    if (name.length < 2)
    {
        error = true;
        $("#dname").css("background-color", "rgb(255, 127, 127)");
    }
    if (name.length > 15)
    {
        error = true;
        $("#dname").css("background-color", "rgb(255, 127, 127)");
    }
//Checks if the name matches the format which only allows upper and lower case letters
//Calls function validName
    if (!validName(name))
    {
        alert ("Name must be more than one letter, less than 15 characters and not contain any numbers.")
        $("#dname").css("background-color", "rgb(255, 127, 127)");
        error=true;
    }
//Checks if the score has only numbers from 0-9 with 3 digits and is a positive and returns a true and adds it to the boolean error if it doesn't match
    if (!validScore(score))
    {
        alert ("Score must contain at least three digits eg. 090 and cannot be a negative")
        $("#score").css("background-color", "rgb(255, 127, 127)");
        error=true;
    }
//Checks if score is above 250 points which it will output and error
    if (score > 250)
    {
        alert ("Score can not be above 250 points")
        $("#score").css("background-color", "rgb(255, 127, 127)");
        error = true;
    }
//If any errors in the data validation, outputs and allert to the user to declare that the input has issues won't be added
    if (error)
        alert("Issues inputting data. Please try again.");
    else
        $("ol").append('<li id = "six"><span>' + name +'</span> - '+ team +' - <span>' + country + '</span> - ' + score + ' Points</li>');
        $("#six").animate({
            right: "-80px",
        });
    //Function to check if name only has letters
function validName(inputtxt) {
    var nameFormat = /^[a-z A-Z]+$/;
    if(inputtxt.match(nameFormat)) 
    {
      return true
    }  
    else 
    {  
      return false
    }
  } 
//Function to check if the score contains only numbers from 1-9 and only has 3 figures
function validScore(inputtxt) {
    var scoreFormat = /^([0-9]{3})+$/;
    if(inputtxt.match(scoreFormat)) 
    {
      return true
    }  
    else 
    {  
      return false
    }
  } 
});
