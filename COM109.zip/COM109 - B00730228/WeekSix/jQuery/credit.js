function validCard(inputtxt) {
  
    //  XXXX XXXX XXXX XXXX
        
    var cardNo = /^([0-9]{4})[ ]?([0-9]{4})\)?[ ]?([0-9]{4})[ ]?([0-9]{4})$/;
      alert(inputtxt + " " + cardNo);
    if(inputtxt.match(cardNo)) 
    {
      return true;
    }  
    else 
    {  
      return false;
    }
  } 
  
    $(document).ready(function() {
  
      $(".error").hide();
      // Have the cursor in the first input box on loading the page
      $("#nameCC").focus();
        
      $('#myForm').submit(function(evt) {
          evt.preventDefault();               // stop the natural HTML FORM submit
          error = false;
          $(".error").hide();
  
          var cardNumber = $("#cardNumber").val();      // get the current email from the FORM
          var name = $("#nameCC").val();    // get the current email from the FORM
         
          // test if it is ok to send
          if (name.length < 4)                // must be at least 4 characters long
          {
              $("#err_name").show();
              error=true;
          }
          if (!validCard(cardNumber))
          {
              $("#err_email").show();
              error=true;
          }
          if (error)
            alert("Issues!");
        else
            console.log("Submitting your inputs as they are valid:" + cardNumber);
          });
        
      // any new p added as a result of the php code executing needs the on method so the event listner can register the interaction
      $("p").on({
          mouseenter: function(){$(this).css("background-color", "lightgray");},
          mouseleave: function(){$(this).css("background-color", "lightblue");},
          dblclick: function(){$(this).css("background-color", "yellow");}
      });
        
    }); // end ready