public class User {
    private String userId, firstName, lastName, email;
    
    public User(String userId, String firstName, String lastName, String email){
        this.userId = userId;
        this.firstName= firstName;
        this.lastName = lastName;
        this.email = email; 
    }
    public String getUserId(){
        return userId;
    }
}
