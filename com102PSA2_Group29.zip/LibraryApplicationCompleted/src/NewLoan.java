public abstract class NewLoan {//Abstract class that assigns the barcode and userId to loans.
    private String barcode, userId;
    public NewLoan(String barcode, String userId){
        this.barcode=barcode;
        this.userId=userId;
    }
    public String getLoanCode(){
        return barcode;
    }
    public String getUserId(){
        return userId;
    }
}
