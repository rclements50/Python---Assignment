import java.io.File;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

public class LibraryApplication {
    private static Item[] item = new Item[20];//Array of 20 objects from Item class
    private static User[] user = new User[10];//Array of 10 objects from User class
    private static ArrayList<Loan> loans = new ArrayList<Loan>();//Array list using Loan class to create objects. Allows for additional objects to be added later.
    private static String[] headers; //Stores headings to be used when writing back to file and used in display as well.
    int positionLoan, positionItem, positionUser; //Used to find ArrayList position of loan, item and user
    
    public static void main(String[] args) {
        LibraryApplication app = new LibraryApplication();
        app.processItems(); // Calls on three processing methods
        app.processUsers();
        app.processLoans();
        app.menu(); // Calls the main menu
    }
        private void menu(){ //Main menu
        int option = 0;
        while (option != 6){ //Loops menu so it appears after each selection unless exit option has been choosen
            System.out.println("-----------------Library Application-----------------\n"); //Displays menu
            System.out.println("Create a loan(1)\t\tRenew an exisiting loan(2)\n");
            System.out.println("Process a return(3)\t\tView all items(4)\n");
            System.out.println("View all loans(5)\t\t\tExit(6)\n");
            System.out.println("-----------------------------------------------------");
            System.out.println("What would you like to do? (Options 1-6)");
            try{ //Catches inputs that aren't an integer number
                Scanner myScanner = new Scanner(System.in);
                option = myScanner.nextInt(); // myScanner picks up on what option has been selected
                switch(option){
                    case 1: //Option 1
                        this.createLoan();
                        break;
                    case 2: //Option 2
                        this.renew();
                        break;
                    case 3: //Option 3
                        this.returnItem();
                        break;
                    case 4: //Option 4
                        this.viewItems();
                        break;
                    case 5: //Option 5
                        this.viewLoans();
                        break;
                    case 6: // Option 6
                        System.out.println("\nSaving to file...");
                        System.out.println("\n\nThank you for using this library application!\nGoodbye!");
                        this.printToFile();
                        break;
                    default: //Invalid option check
                        System.out.println("Please enter a valid selection");         
                }
            }
            catch (InputMismatchException e){
                System.out.println("Please enter a valid selection!");
            }
        }
    }
    private void processItems(){
        int x = 0; 
        try {
        File file = new File("ITEMS(1).csv");
        Scanner scanner = new Scanner(file);
        String data = scanner.nextLine(); //Skips first line - titles
        while (scanner.hasNext()) {
            data = scanner.nextLine(); // Reads in whole line into data variable
            String [] dataArray = data.split(","); // Splits data into array using comma
            item[x] = new Item(dataArray[0], dataArray[1], dataArray[2], //Creates new object using data array
                    dataArray[3], dataArray[4], dataArray[5]);
            x++;
        }
        scanner.close();
        }
        catch (FileNotFoundException e) { //Catches error if file isn't found
        System.out.println("Error - Item file not found");
        }
    }
    private void processUsers(){
        int x = 0;
        try {
        File file = new File("USERS(1).csv");
        Scanner scanner = new Scanner(file);
        String data = scanner.nextLine();
        while (scanner.hasNext()) {
            data = scanner.nextLine(); // Reads in whole line into data variable
            String [] dataArray = data.split(","); // Splits data into array using comma
            user[x] = new User(dataArray[0], dataArray[1], dataArray[2], //Creates new object using data array
                    dataArray[3]);
            x++;
        }
        scanner.close();
        }
        catch (FileNotFoundException e) { //Catches error if file isn't found
            System.out.println("Error - User file not found");
        }
    }
    private void processLoans(){        
        try {
            File file = new File("LOANS(1).csv");
            Scanner scanner = new Scanner(file);
            String data = scanner.nextLine();
            headers = data.split(",");
            while (scanner.hasNext()){
                data = scanner.nextLine();
                String [] dataArray = data.split(",");
                loans.add(new Loan(dataArray[0], dataArray[1], dataArray[2],
                dataArray[3], dataArray[4]));
            }
            scanner.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("Error - Loan file not found");
        }
    }
    private void createLoan(){
        String search; //To store users search
        positionUser = 0; //To hold location of user in user array
        positionItem = 0; //To hold location of item in item array
        boolean foundUser = false;
        boolean foundItem = false;
        Scanner scanner = new Scanner(System.in);
        System.out.println("-----------------Create a loan-----------------");
        System.out.println("Please enter the user ID: ");
        search = scanner.next();
        for(int x = 0; x < user.length && foundUser == false; x++){
            if (user[x].getUserId().equals(search)){ //Checks through all users to see if id exists and records position
                positionUser = x;
                foundUser = true;
            }
        } //If user exists, moves onto item query
        if (foundUser == true){
            System.out.println("Please enter the item ID: ");
            search = scanner.next();
            for(int y = 0; y < item.length && foundItem == false; y++){
                if (item[y].getItemCode().equals(search)){ //Checks through all items to see if barcode exists and records position
                    positionItem = y;
                    foundItem = true;
                }
            } //If item exists too, goes through process of creating new loan object
            if (foundItem == true){
                System.out.println("Adding item loan...");
                loans.add(new Loan(item[positionItem].getItemCode(), user[positionUser].getUserId())); //If id and barcode exists, creates object adding onto arrayList
                loans.get(loans.size() - 1).setDueDate(item[positionItem].getType()); //Calls setDueDate and sends item type
                System.out.println(headers[0] + "\t\t" + headers[1] + "\t\t" + headers[2] + "\t" + headers[3] + "\t" + headers[4]);
                loans.get(loans.size() - 1).displayLoan(); //Prints out new loan
            }
            else
                System.out.println("No item found with that ID");   
            }
        else
            System.out.println("No user found with that ID");   
    }
    private void viewItems(){ //Displays all item objects in program
        System.out.println("-----------------Item Report-----------------"); 
        System.out.printf( "%-15s%-22s%-42s%-22s%-22s%-12s\n" ,"Barcode" ,"Author","Title","Type","Year","ISBN");//Formatted headings 
        for(int x = 0; x < item.length; x++){
            item[x].displayItem(); // Goes through array of objects and calls display method for each one
        }
    }
    private void viewLoans(){
        System.out.println("-----------------Loan Report-----------------");
        System.out.println(headers[0] + "\t\t" + headers[1] + "\t\t" + headers[2] + "\t" + headers[3] + "\t" + headers[4]);
        for(int x = 0; x < loans.size(); x++){
            loans.get(x).displayLoan();
        }   
    } 
    private void returnItem(){ //Used to process a return of an item on loan
        int positionLoan = 0; //Used to find ArrayList position of loan
        
        Boolean found = false;
        String search; // Holds users barcode search
        System.out.println("-----------------Return-----------------");
        System.out.println("What loan would you like to return? ");
        System.out.println("Please enter the barcode of the loan you would like to return: ");
        Scanner scanner = new Scanner(System.in);
        search = scanner.next(); //User inputs the loan they are searching for
        for(int x = 0; x < loans.size() && found == false; x++){
            if (search.equals(loans.get(x).getLoanCode())){ //Itterates through loans until finds a match or comes to the end
                System.out.println("Match found");
                positionLoan = x; //Records position in loan list of where it was found
                found = true;
            }
        }
        if (found == true)
        {
            if (loans.get(positionLoan).checkDate()==true){
                loans.remove(positionLoan);
                System.out.println("Loan returned."); 
            }
            else{
                loans.remove(positionLoan);
                System.out.println("Loan was returned past due date. Consult overdue policy!"); //As no overdue loan process has been specified, outputs error message
            } 
        }
        else
            System.out.println("No barcode found");
    }
    
    private void renew(){ //Method to renew current loans - option 2
        positionLoan = 0;
        positionItem = 0;
        Boolean found = false;
        String search; // Holds users barcode search
        System.out.println("-----------------Renew-----------------");
        System.out.println("What loan would you like to renew? ");
        System.out.println("Please enter the barcode you would like to search for: ");
        Scanner scanner = new Scanner(System.in);
        search = scanner.next(); //User inputs the loan they are searching for
        for(int x = 0; x < loans.size() && found == false; x++){
            if (search.equals(loans.get(x).getLoanCode())){ //Itterates through loans until finds a match or comes to the end
                System.out.println("-----------------Match Found-----------------");
                System.out.println(headers[0] + "\t\t" + headers[1] + "\t\t" + headers[2] + "\t" + headers[3] + "\t" + headers[4]);
                loans.get(x).displayLoan();
                System.out.println("---------------------------------------------");
                positionLoan = x; //Records position in loan list of where it was found
                found = true;
                for(int y =0; y < item.length; y++){ //Searches for position in item array
                    if (search.equals(item[y].getItemCode())){
                        positionItem = y; //Records position of matching item for checking if it's a book or multimedia item, later
                    }  
                }
            }
        }
        if (found == true){ //Finds the type of loan and number of renews
            if (loans.get(positionLoan).getRenews() >= 3 && item[positionItem].getType().equals("Book")){
                System.out.println("Too many renews! Books can have no more than 3 renews. Please return by due date: " + loans.get(positionLoan).getDueDate());
            }
            else if (loans.get(positionLoan).getRenews() >= 2 && item[positionItem].getType().equals("Multimedia")){
                System.out.println("Too many renews! Multimedia items can have no more than 2 nenews. Please return by due date: "  + loans.get(positionLoan).getDueDate());
            }
            else{ //If valid number of renews
                System.out.println("Renewing");
                loans.get(positionLoan).updateRenews();//Calls method that will iterate renews by one
                loans.get(positionLoan).updateDueDate(item[positionItem].getType());
                /*if (item[positionItem].getType().equals("Book"))
                    loans.get(positionLoan).updateDueDate(); //If it's a book, calls method to add 2 weeks to due date   
                else
                    loans.get(positionLoan).updateDueDate(); //If it's multimedia, calls method to add 1 week to due date */  
                System.out.println("New due date: " + loans.get(positionLoan).getDueDate()); //Prints new due date for loan
            }
        }
        else
            System.out.println("No match found"); //Prints if no matching loan barcode is found
    }
    private void printToFile(){ //Prints all loan objects back into LOANS(1).csv one line at a time using a comma as a cell seperator
        try{
            FileWriter writer = new FileWriter("LOANS(1).csv", false);
            for (int x = 0; x < headers.length; x++){
                writer.write(headers[x]);
                writer.write(",");
            }
            writer.write("\n");
            for (int y = 0; y < loans.size(); y++){
                writer.write(loans.get(y).toPrint());
                writer.write("\n");
            }
            writer.close();  
        }
        catch(IOException e){
            System.out.println("Error trying to save. Please ensure LOANS(1).csv is not open during application operation to ensure data integrity!");
        }
    }
}
