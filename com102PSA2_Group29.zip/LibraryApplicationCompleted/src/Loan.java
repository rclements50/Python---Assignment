import java.time.format.DateTimeFormatter;
import java.time.LocalDate;

public class Loan extends NewLoan{
    DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private LocalDate issueDate, dueDate, currentDate;
    private int renews = 0;
    
    public Loan(String barcode, String userId, String issueDate, String dueDate,
            String renews){ //Constructor for loans being read in from .csv file
        super(barcode, userId); //Calls on parent class constructor
        this.issueDate=LocalDate.parse(issueDate, format);
        this.dueDate=LocalDate.parse(dueDate, format);
        this.renews=Integer.parseInt(renews); 
    }
    public Loan(String barcode, String userId){//Overloaded constructor allows for new loans to be processed differently.
        super(barcode, userId);
        this.issueDate = issueDate.now();
        this.renews = 0;
    }
    public void setDueDate(String type){
        if (type.equals("Multimedia"))//Checks for product type before assigning due date value
            this.dueDate = issueDate.plusWeeks(1);//One week for multimedia items
        else
            this.dueDate = issueDate.plusWeeks(4);//Four weeks for books
    }
    public void displayLoan(){
        System.out.println(this.getLoanCode() + "\t" + this.getUserId() + "\t" + format.format(issueDate) + "\t" + format.format(dueDate) + "\t" + renews);    
    }
    public int getRenews(){
        return renews;
    }
    public LocalDate getDueDate(){
        return dueDate;
    }
    public void updateRenews(){
        renews++;
    }
    public void updateDueDate(String type){
        if(type.equals("Multimedia"))
            this.dueDate = dueDate.plusWeeks(1);
        else
            this.dueDate = dueDate.plusWeeks(2);
    }
    public boolean checkDate(){
        if (currentDate.now().isBefore(dueDate)|| currentDate.now().isEqual(dueDate)){
            return true;
        }
        else return false;
    }
    public String toPrint(){
        return this.getLoanCode() + "," + this.getUserId()+ "," + format.format(issueDate) + "," + format.format(dueDate) + "," + renews;
    } 
}
